package com.scc.client.controller;

import com.scc.client.configuration.Configuration;
import com.scc.client.limits.Limits;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import static com.scc.client.constant.Constants.limit_Endpoint;


@RestController
public class limitscontroller {

//    @Autowired
//    RestTemplate restTemplate;

    @Autowired
    Configuration config;


    @GetMapping(limit_Endpoint)
    public Limits retriveLimits()
    {
        return new Limits(config.maximum,config.minimum);
    }
}
