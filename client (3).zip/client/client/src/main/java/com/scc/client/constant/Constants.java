package com.scc.client.constant;

public class Constants {
    public  static  final  String limit_Endpoint ="/limits";
}
